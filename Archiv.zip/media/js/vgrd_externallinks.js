(function($) {
    var PlgSysExternalLinkWarning = function(options) {
      var root = this;
      var vars = {
        hostname: null,
        options: {
          sitename: false,
          excludedclasses: '{"classes":[]}',
          excludeddomains: '{"domains":[]}',
          uselinkicon: false,
          linkicon: "",
          linkiconexcludeclasses: '{"classes":[]}'
        }
      };
      this.construct = function(options) {
        var m = ["excludedclasses", "excludeddomains", "linkiconexcludeclasses"];
        $.each(options, function(key, value) {
          vars.options[key] = (m.indexOf(key) == -1) ? value : value
        });
        vars.hostname = getHostname(window.location.href);
        var k = findLinks();
        if (options.uselinkicon) {
          g(k)
        }
      }
      ;
      this.showVars = function() {
        return vars
      }
      ;
      var getHostname = function(k) {
        var l = document.createElement("a");
        l.href = k;
        return l.hostname
      };
      var findLinks = function() {
        var links = [];
        var n, k, m;
        $.each($("a"), function(i, el) {
          k = true;
          n = getHostname(el.href);
          m = el.className.split(/\s+/);
          if (el.href.substring(0, 10) !== "javascript" && n !== vars.hostname && $.inArray(n, vars.options.excludeddomains.domains) === -1 && h(vars.options.excludedclasses, m).length === 0) {
            links.push(el);
            $(el).click(function(e) {
              e.stopPropagation();
              e.preventDefault();
              linkWarning(el.href)
            })
          }
        });
        return links
      };
      var h = function(l, k) {
        return $.map(l, function(m) {
          return $.inArray(m, k) < 0 ? null : m
        })
      };
      var linkWarning = function(url) {
        var k = getHostname(url);
        if (confirm(Joomla.JText._("PLG_SYS_EXTERNALLINKWARNINGPRO_WARNINGTEXT").replace("{domain}", vars.hostname).replace("{destdomain}", k).replace("{sitename}", vars.options.sitename))) {
          window.open(url, "_blank")
        }
      };
      var g = function(k) {
        $.each(k, function(l, m) {
          if (h(vars.options.linkiconexcludeclasses, m.className.split(/\s+/)) >= 1) {
            return true
          }
          $.each(vars.options.linkicon.split(" "), function(n, o) {
            $(m).addClass(o)
          })
        })
      };
      this.construct(options)
    };
    $(document).ready(function() {
      var myOptions = Joomla.getOptions('plg_system_externallinkwarningpro');
      window.plg_system_externallinkwarningpro = new PlgSysExternalLinkWarning(myOptions);
    })
  }
)(jQuery);
