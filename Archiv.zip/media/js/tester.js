(function(b) {
    var a = function(f) {
      var c = this;
      var j = {
        hostname: null,
        options: {
          sitename: false,
          excludedclasses: '{"classes":[]}',
          excludeddomains: '{"domains":[]}',
          uselinkicon: false,
          linkicon: "",
          linkiconexcludeclasses: '{"classes":[]}'
        }
      };
      this.construct = function(l) {
        var m = ["excludedclasses", "excludeddomains", "linkiconexcludeclasses"];
        b.each(l, function(n, o) {
          j.options[n] = (m.indexOf(n) == -1) ? o : JSON.parse(o)
        });
        j.hostname = i(window.location.href);
        var k = e();
        if (l.uselinkicon) {
          g(k)
        }
      }
      ;
      this.showVars = function() {
        return j
      }
      ;
      var i = function(k) {
        var l = document.createElement("a");
        l.href = k;
        return l.hostname
      };
      var e = function() {
        var l = [];
        var n, k, m;
        b.each(b("a"), function(o, p) {
          k = true;
          n = i(p.href);
          m = p.className.split(/\s+/);
          if (p.href.substring(0, 10) !== "javascript" && n !== j.hostname && b.inArray(n, j.options.excludeddomains.domains) === -1 && h(j.options.excludedclasses, m).length === 0) {
            l.push(p);
            b(p).click(function(q) {
              q.stopPropagation();
              q.preventDefault();
              d(p.href)
            })
          }
        });
        return l
      };
      var h = function(l, k) {
        return b.map(l, function(m) {
          return b.inArray(m, k) < 0 ? null : m
        })
      };
      var d = function(l) {
        var k = i(l);
        if (confirm(Joomla.JText._("PLG_SYS_EXTERNALLINKWARNINGPRO_WARNINGTEXT").replace("{domain}", j.hostname).replace("{destdomain}", k).replace("{sitename}", j.options.sitename))) {
          window.open(l, "_blank")
        }
      };
      var g = function(k) {
        b.each(k, function(l, m) {
          if (h(j.options.linkiconexcludeclasses, m.className.split(/\s+/)) >= 1) {
            return true
          }
          b.each(j.options.linkicon.split(" "), function(n, o) {
            b(m).addClass(o)
          })
        })
      };
      this.construct(f)
    };
    b(document).ready(function() {
      window.plg_system_externallinkwarningpro = new a(window.plg_system_externallinkwarningpro_options)
    })
  }
)(jQuery);
